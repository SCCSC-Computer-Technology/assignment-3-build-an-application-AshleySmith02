namespace ASmith_Lab_3_State_Class_Library
{
    partial class StateDataDataContext
    {
    }
}